import React from 'react'
import {Link} from 'react-router';

export default class PostComponent extends React.Component{
    render(){
        
        return  <div className="row postStyle">
            <div className="col-md-2">
            
            <Link to={`/photo/${this.props.post.code}`}>            
            <img src={this.props.post.display_src} height="100px"width="100px"/>

            </Link>
            </div>
            <div className="col-md-4">
            <h3> {this.props.post.caption}</h3>
            <button  type="button" 
            onClick={this.props.IncrementLikes.bind(null,this.props.i)} className="btn btn-primary">&nbsp;{this.props.post.likes} <span className="glyphicon glyphicon-thumbs-up"></span></button>
             </div>
             </div>
    }
}