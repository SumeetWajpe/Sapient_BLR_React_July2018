import {connect} from 'react-redux';


import * as allActions from '../actions/actions';
import { bindActionCreators } from 'redux';
import MainComponent from './main.component';

function mapStateToProps(storeData){
            return{
                myposts:storeData.posts,
                mycomments:storeData.comments
            }
}

function mapDispatchToProps(dispatcher){
        return bindActionCreators(allActions,dispatcher);
}


var app = connect(mapStateToProps,mapDispatchToProps)(MainComponent)
export default app;
