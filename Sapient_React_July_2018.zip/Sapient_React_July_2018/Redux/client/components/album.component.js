import React from 'react'
import PostComponent from './posts.component';


export default class AlbumComponent extends React.Component{
    render(){
        
        let allPostsToBeCreated = this.props.myposts.map(
            (p,index)=> <PostComponent
             key={p.id} 
             i={index} 
             post={p} {...this.props} />
        )


        return <div className="container">
             <h1 className="jumbotron"> Album Component </h1>
             {allPostsToBeCreated}
             </div>
    }
}