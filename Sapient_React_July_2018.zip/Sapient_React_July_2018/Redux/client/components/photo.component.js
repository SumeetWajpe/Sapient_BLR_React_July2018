import React from 'react'
import PostComponent from './posts.component';


export default class PhotoComponent extends React.Component{
    render(){

        let code = this.props.params.code; // fetch the code from Url !
        var index = this.props.myposts.findIndex((p)=> p.code == code);

        let currPost = this.props.myposts.find(
            (p,i)=>{
                if(p.code == code){
                    return true;
                }
            }
        )
        return <div>
            <h1> Post Details </h1>
                <PostComponent
                post={currPost}
                i={index}
                {...this.props}
                />      
                
            </div>
    }
}