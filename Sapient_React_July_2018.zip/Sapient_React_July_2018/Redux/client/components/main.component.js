import React from 'react';
// import {fetchPostsData} from '../actions/actions';

export default class MainComponent extends React.Component{
    
    componentDidMount(){
            this.props.fetchPostsData();
    }    
    
    render(){       


            console.log(this.props)

        return <div>           

             {React.cloneElement(this.props.children,this.props)}
             </div>
    }
}