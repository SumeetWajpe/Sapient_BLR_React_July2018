import {createStore,applyMiddleware} from 'redux';
import thunk from 'redux-thunk';
import rootReducer from './reducers/rootReducer';
import posts from './data/posts';
import comments from './data/comments';

// var defaultStore = {posts,comments};

var store = createStore(rootReducer,applyMiddleware(thunk));

export default store;


