// Action Creators !
import axios from 'axios';

export function IncrementLikes(index){
    return {type:'INCREMENT_LIKES',index}
}

export function DecrementLikes(){
    return {type:'DECREMENT_LIKES'}
}

export function AddComment(){
    return {type:'ADD_COMMENT'}
}

export function fetchPostsData(){
    var request = axios.get('https://api.myjson.com/bins/wo14q')
    
    return  (dispatch)=>{
        request.then(
            (response)=>{
                console.log(' FETCH_POSTS dispatched !')
                dispatch({type:'FETCH_POSTS',response:response.data})
            },
            (err)=>{console.log(err)}
        )
    }
}