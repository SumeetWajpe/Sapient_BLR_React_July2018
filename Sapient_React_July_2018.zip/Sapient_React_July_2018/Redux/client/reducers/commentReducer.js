export default function comments(defStore=[],action){
   switch(action.type){
            case 'ADD_COMMENT':
            console.log('Action:ADD_COMMENT ! Comments Reducer Called!');
            return defStore;// return an updated store !

            default:
            return defStore;
   }
}