import comments from './commentReducer';
import posts from './postsReducer';

import {combineReducers} from 'redux';

var rootReducer = combineReducers({
    posts,comments
})

export default rootReducer;