export default function posts(defStore=[],action){
    switch(action.type){

        case 'FETCH_POSTS':
        console.log(defStore)
                defStore = action.response; // imp !
                return defStore;
        case 'INCREMENT_LIKES':
            let index = action.index;


            return [
                    ...defStore.slice(0,index),
                    {...defStore[index],likes:defStore[index].likes + 1},
                    ...defStore.slice(index+1)
            ];
            
             default:
             return defStore;
    }
 }