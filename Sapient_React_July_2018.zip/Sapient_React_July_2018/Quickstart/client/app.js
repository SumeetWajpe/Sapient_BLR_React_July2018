import React from 'react'; // ?? import React object from React package !
import ReactDOM from 'react-dom';
// import {PI,CourseComponent} from './course.component';
import CourseComponent from './course.component';
import ListOfCourses from './listofcourses.component';
import ButtonComponent from './button.component';
import ListOfButtonsComponent from './listOfButtons.component';
import LifeCycleComponent from './lifecyclehooks.component';
import PostsComponent from './posts.component';



ReactDOM.render( 
    <ListOfButtonsComponent allbuttons={[100,200,300,400]} />,
document.getElementById('content')); 


// ReactDOM.render( <ListOfButtonsComponent />,  
// document.getElementById('content')); 