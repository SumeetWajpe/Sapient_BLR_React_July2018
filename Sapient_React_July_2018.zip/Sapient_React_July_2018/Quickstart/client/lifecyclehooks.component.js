import React from 'react';
import ReactDOM from 'react-dom'

export default class LifeCycleComponent extends React.Component{
    
    constructor(props){
        super(props);
        console.log('With in Constructor !');
    }
        
    componentWillMount(){  // For initializing state !
        this.state = {companyName:'IBM'};
        console.log('With in componentWillMount !')            
    }
    componentDidMount(){  // For access to DOM        
        console.log('With in componentDidMount !')            
    }   
    shouldComponentUpdate(){   // when setState gets called !       
        console.log('With in shouldComponentUpdate !') ;  
        //console.log('State : ' + this.state.companyName);
       // console.log('Arguments : ' + arguments[1].companyName);
        // if(arguments[1].companyName.length > 5){
        //     return false;
        // }
        return true;      
    }
    componentWillUpdate(){
        console.log('With in componentWillUpdate !') ;  
    }
    componentDidUpdate(){
        console.log('With in componentDidUpdate !') ;  
    }    
    OnChangeHandler(e){       // change the state !
        this.setState({companyName:e.target.value})
    }

    componentWillUnmount(){
        console.log('Unmouting...')
    }
    DeleteHandler(){
        ReactDOM.unmountComponentAtNode(document.getElementById('content'))
    }
    render(){        
        console.log('Within Render !')
        return  <div>
            <input type="text" 
            onChange={this.OnChangeHandler.bind(this)}
            value={this.state.companyName}            />
            <b>{this.state.companyName}</b>

            <input type="button" value="Delete !" onClick={this.DeleteHandler.bind(this)} />
            </div>
        
    }
}