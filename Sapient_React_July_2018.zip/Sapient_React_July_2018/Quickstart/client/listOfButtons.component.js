import React from 'react';
import ReactDOM from 'react-dom';
import ButtonComponent from './button.component';

export default class ListOfButtonsComponent extends React.Component{
           
    constructor(props){
        super(props);
        this.state = {buttonscount:this.props.allbuttons};
    }
    AddButtonHandler(){
        // change the state !
        let txtValue = ReactDOM.findDOMNode(this.refs.inputValue).value
        this.setState({buttonscount:[...this.state.buttonscount,txtValue]})
    }
    render(){          
        var allButtonsToBeCreated = this.state.buttonscount.map(
            (b,i) =>  <ButtonComponent initialCount={b} key={i}  />
        );        
        return <div>
            <input type="text"  ref="inputValue"  /> 
            <input type="button" className="btn btn-success btn-sm" 
            value="Add"            
            onClick={this.AddButtonHandler.bind(this)}            />
        <br/>
                {allButtonsToBeCreated}
            </div>
    }
}