import React from 'react';
import axios from 'axios';

export default class PostsComponent extends React.Component{
    componentWillMount(){
        this.state = {posts:[]}
    }
    componentDidMount(){
        let aPromise =    axios.get('https://jsonplaceholder.typicode.com/posts')
        aPromise.then(
            (res)=>{
              // console.log(res.data)
              this.setState({posts:res.data})
            }
           
        ).catch( (err)=>{
            console.log(err)
        })
    }
    render(){  
        var postsToBeCreated = this.state.posts.map(
            (p,i) =><li key={p.id}  > {p.title} </li>
            
        );
        return <ul>
            {postsToBeCreated}
            </ul>
    }
}