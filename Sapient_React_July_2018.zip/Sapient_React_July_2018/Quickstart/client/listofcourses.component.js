import React from 'react';
import CourseComponent from './course.component';

export default class ListOfCoursesComponent extends React.Component{
    
    constructor(){
        super();
        this.courses = ["React","Redux","Angular"];
    }    
    
    render(){        

        var allCoursesToBeCreated = this.courses.map(
            course => <CourseComponent name={course} />
        )
        return <div>
                    {allCoursesToBeCreated}
                {/*<CourseComponent name={this.course} />
                 <CourseComponent name="Node"  />
                <CourseComponent name="Redux"  /> */}
            </div>
    }
}